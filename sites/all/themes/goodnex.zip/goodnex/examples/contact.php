<div class="nine columns">
  <h4 class="content-title">Let's Keep in Touch </h4>
  <?php $block = module_invoke('contact_form_blocks', 'block_view', '0'); ?>	
  <?php print $block['content']; ?>
</div>
<div class="three columns">&nbsp;</div>

<div class="four columns">

	<h4 class="content-title">Main Office</h4>

	<p>
		<b>Address:</b> 12 Street, Los Angeles, CA, 94101<br>
		<b>Phone:</b> +1 800 123 4567<br>
		<b>FAX:</b> +1 800 891 2345<br>
		<b>Email:</b> testmail@sitename.com<br>
	</p>

</div><!--/ .columns-->