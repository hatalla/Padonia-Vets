jQuery(document).ready(function ($) {
      
  $("#google_map").fitMaps( {w: '100%', h:'370px'} );   

});