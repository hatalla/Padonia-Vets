<li class="ajax-navigation-item">
<?php print render($content['body']); ?>
</li>