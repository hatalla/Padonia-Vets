<li>
	<a title="<?php print $title; ?>" href="<?php print $node_url; ?>"><?php print $title; ?></a>
	<span class="post-date"><?php print format_date($node->created, 'custom', 'M d, Y'); ?></span>
</li>